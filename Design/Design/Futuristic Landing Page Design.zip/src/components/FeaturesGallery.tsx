import { motion } from "motion/react";
import { 
  Code2, 
  Mic, 
  FolderTree, 
  Play, 
  History, 
  Users, 
  Layers,
  Sparkles 
} from "lucide-react";

const features = [
  {
    icon: Code2,
    title: "Real-time Collaborative Editing",
    description: "Code together with your team in perfect sync. See cursors, edits, and changes as they happen.",
    gradient: "from-cyan-400 to-blue-500",
    iconBg: "bg-cyan-500/20",
  },
  {
    icon: Mic,
    title: "Built-in Voice Chat",
    description: "Communicate seamlessly without leaving your workspace. Crystal-clear audio for focused discussions.",
    gradient: "from-purple-400 to-pink-500",
    iconBg: "bg-purple-500/20",
  },
  {
    icon: FolderTree,
    title: "Multi-file Project Workspace",
    description: "Organize complex projects with ease. Navigate through files, folders, and assets intuitively.",
    gradient: "from-emerald-400 to-cyan-500",
    iconBg: "bg-emerald-500/20",
  },
  {
    icon: Play,
    title: "Code Execution Sandbox",
    description: "Test and run code instantly in isolated environments. Support for multiple languages and frameworks.",
    gradient: "from-orange-400 to-red-500",
    iconBg: "bg-orange-500/20",
  },
  {
    icon: History,
    title: "Version History",
    description: "Travel through time with complete version control. Never lose a line of code with automatic snapshots.",
    gradient: "from-blue-400 to-indigo-500",
    iconBg: "bg-blue-500/20",
  },
  {
    icon: Users,
    title: "Live Presence Indicators",
    description: "See who's online, what they're editing, and where they are in the codebase at all times.",
    gradient: "from-pink-400 to-purple-500",
    iconBg: "bg-pink-500/20",
  },
  {
    icon: Layers,
    title: "Room-based Collaboration",
    description: "Create dedicated coding rooms for teams, projects, or quick pair programming sessions.",
    gradient: "from-cyan-400 to-purple-500",
    iconBg: "bg-cyan-500/20",
  },
  {
    icon: Sparkles,
    title: "AI-Powered Assistance",
    description: "Get intelligent code suggestions, refactoring tips, and debugging help from our AI copilot.",
    gradient: "from-yellow-400 to-orange-500",
    iconBg: "bg-yellow-500/20",
  },
];

export function FeaturesGallery() {
  return (
    <section className="relative py-32 px-8 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-1/2 left-0 w-96 h-96 rounded-full blur-3xl opacity-10"
          style={{
            background: 'radial-gradient(circle, rgba(0, 229, 255, 0.6) 0%, transparent 70%)',
          }}
          animate={{
            x: [0, 100, 0],
            y: [-50, 50, -50],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      <div className="relative z-10 max-w-[1600px] mx-auto">
        {/* Section heading */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl xl:text-6xl mb-4">
            <span className="relative inline-block">
              <span className="absolute inset-0 blur-2xl bg-gradient-to-r from-cyan-400 to-purple-600 opacity-50" />
              <span className="relative bg-gradient-to-r from-cyan-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                Everything you need to code together
              </span>
            </span>
          </h2>
        </motion.div>

        {/* Auto-scrolling gallery container */}
        <div className="relative">
          {/* Gradient fade edges */}
          <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-[#0a0a0f] to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-[#0a0a0f] to-transparent z-10 pointer-events-none" />

          {/* Scrolling track */}
          <div className="overflow-hidden">
            <motion.div
              className="flex gap-8"
              animate={{
                x: [0, -2000],
              }}
              transition={{
                x: {
                  duration: 40,
                  repeat: Infinity,
                  ease: "linear",
                },
              }}
            >
              {/* Duplicate features for seamless loop */}
              {[...features, ...features, ...features].map((feature, index) => (
                <FeatureCard key={index} feature={feature} />
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ feature }: { feature: typeof features[0] }) {
  return (
    <motion.div
      className="relative group min-w-[420px] h-[280px]"
      whileHover={{ scale: 1.05, y: -10 }}
      transition={{ duration: 0.3 }}
    >
      {/* Glow effect on hover */}
      <div 
        className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-20 blur-2xl transition-opacity duration-500`}
      />

      {/* Glass card */}
      <div className="relative h-full p-8 rounded-3xl backdrop-blur-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/10 group-hover:border-white/30 transition-all duration-300 overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1668877248122-9d165544b479?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGdlb21ldHJpYyUyMG5lb258ZW58MXx8fHwxNzYzODk0MzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }} />
        </div>

        {/* Animated gradient overlay */}
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
        />

        {/* Icon */}
        <motion.div
          className={`relative w-16 h-16 rounded-2xl ${feature.iconBg} backdrop-blur-xl border border-white/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
          whileHover={{ rotate: [0, -10, 10, 0] }}
          transition={{ duration: 0.5 }}
        >
          <feature.icon className={`w-8 h-8 bg-gradient-to-br ${feature.gradient} bg-clip-text text-transparent`} strokeWidth={2} />
        </motion.div>

        {/* Content */}
        <div className="relative space-y-3">
          <h3 className="text-xl tracking-tight">
            {feature.title}
          </h3>
          <p className="text-sm text-gray-400 leading-relaxed">
            {feature.description}
          </p>
        </div>

        {/* Decorative elements */}
        <div className="absolute bottom-4 right-4 flex gap-1">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className={`w-2 h-2 rounded-full bg-gradient-to-br ${feature.gradient}`}
              animate={{
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.3,
              }}
            />
          ))}
        </div>

        {/* Orbital ring decoration */}
        <motion.div
          className="absolute -top-10 -right-10 w-32 h-32 rounded-full border border-white/10"
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <div className={`absolute top-1/2 left-0 w-2 h-2 rounded-full bg-gradient-to-br ${feature.gradient} -translate-y-1/2`} />
        </motion.div>
      </div>
    </motion.div>
  );
}
