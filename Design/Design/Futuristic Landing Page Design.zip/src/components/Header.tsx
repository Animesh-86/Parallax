import { motion } from "motion/react";

export function Header() {
  const navItems = ["Pricing", "About", "Sign Up", "Login"];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-8 py-6">
      <div className="max-w-[1600px] mx-auto flex items-center justify-between">
        {/* Left Navigation */}
        <nav className="flex items-center gap-2">
          {navItems.map((item, index) => (
            <motion.button
              key={item}
              className="relative px-6 py-2.5 rounded-full text-sm backdrop-blur-xl bg-white/5 border border-white/10 hover:border-cyan-400/50 hover:bg-white/10 transition-all duration-300 group overflow-hidden"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              {/* Neon glow effect on hover */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-400/0 via-cyan-400/20 to-cyan-400/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <span className="relative z-10">{item}</span>
            </motion.button>
          ))}
        </nav>

        {/* Right Logo */}
        <motion.div
          className="relative"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <div className="relative px-8 py-3 rounded-2xl backdrop-blur-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 shadow-2xl">
            {/* Subtle neon edge glow */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-400/20 via-purple-500/20 to-cyan-400/20 blur-xl opacity-50" />
            
            <h1 className="relative z-10 text-2xl tracking-wider bg-gradient-to-r from-cyan-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
              CodeAstra
            </h1>
          </div>
        </motion.div>
      </div>
    </header>
  );
}
