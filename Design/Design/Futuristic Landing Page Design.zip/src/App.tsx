import { Header } from "./components/Header";
import { HeroSection } from "./components/HeroSection";
import { FeaturesGallery } from "./components/FeaturesGallery";
import { CosmicBackground } from "./components/CosmicBackground";

export default function App() {
  return (
    <div className="relative min-h-screen bg-[#0a0a0f] text-white overflow-hidden">
      <CosmicBackground />
      
      <div className="relative z-10">
        <Header />
        <HeroSection />
        <FeaturesGallery />
      </div>
    </div>
  );
}
